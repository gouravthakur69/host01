

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session ('message')); ?></div>    
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
            <h3>Edit Slider
                <a href="<?php echo e(url('admin/sliders/')); ?>" class="btn btn-primary btn-sm text-white float-end"> 
                    Back
                </a>
            </h3>
            </div>
            <div class="card-body">

            <form action="<?php echo e(url('admin/sliders/'.$slider->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>;

                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" name="title" value="<?php echo e($slider->title); ?>" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo e($slider->description); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label>Image</label>
                        <input type="file" name="image" class="form-control" />
                        <img src="<?php echo e(asset("$slider->image")); ?>" style="width: 50; hieght: 50px" alt="slider" />
                    </div>

                    <div class="mb-3">
                        <label>Status</label><br/>
                        <input type="checkbox" name="status" <?php echo e($slider->status == '1' ? 'checked':''); ?> style="width:30px;height:30px" /> 
                        Checked=Hidden,UnChecked=Visible
                    </div>

                    <div class="mb-3">
                      <button type="submit" class="btn btn-primary">update</button>
                    </div>

                </form>



            
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\om\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>