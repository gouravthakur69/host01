<?php $__env->startSection('content'); ?>

<h1 class="text-center mt-2"><?php echo e($product->title); ?> | Detail</h1>
<hr>
<br>


<div class="container">
    <div class="row">
        <div class="col-md-9" style="display:flex">

            <div class="container m-2 p-2">
                <img src="/images/<?php echo e($product->picture); ?>" height="450px" alt="...">
                <div class="container m-2 p-2">
                  <h2><?php echo e($product->title); ?></h2>
                  <h3>Price: $<?php echo e($product->price); ?></h3>
                  <hr>
                  <p><?php echo e($product->description); ?></p>
                  <a href="<?php echo e(route('product.index')); ?>" class="btn btn-success">Go Home</a>
                  <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-primary">Edit</a>
                </div>
              </div>

        </div>


        <div class="col-md-3">
            <h3>All Comments</h3>

            <div class="comments p-2 m-2" style="background-color: rgb(232, 251, 246)">
                <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><?php echo e($comment->comment); ?> ( <?php echo e($comment->rating); ?> )</h5>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


           <h3>Add Comment...</h3>

           <div class="container m-2 p-2">

            <form action="" method="POST">
                <?php echo csrf_field(); ?>

                <input type="hidden" id="id" name="id" value="<?php echo e($product->id); ?>">

                <div class="mb-3">
                    <label for="comment" class="form-label">Comment</label>
                    <input type="text" class="form-control" name="comment" id="comment" placeholder="Enter Comment">
                </div>

                <div class="mb-3">
                    <label for="rating" class="form-label">Rating</label>
                    <input type="number" class="form-control" name="rating" id="rating" placeholder="Enter Rating">
                </div>

                  <button type="submit" id="addCommentBtn" class="btn btn-success">comment</button>

            </form>

           </div>



        </div>
    </div>
</div>


<script>


$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
    }
})



// Add Comment To Product By Id

$("#addCommentBtn").click(function(e){

    //e.preventDefault();
    var comment = $('#comment').val();
    var rating =  $('#rating').val();
    var id = $('#id').val();


    $.ajax({
        type: "POST",
        dataType: "json",
        data: {comment:comment, rating:rating, _token: '<?php echo e(csrf_token()); ?>'},
        url: "/products/"+$id,
        success: function(data) {
            console.log('Added Comment');
        },
        error: function(error) {
            console.log(error.responseJSON.errors.comment);
            console.log(error.responseJSON.errors.rating);
        }
    });




});




// Load Comment By Product Id

// function allComments() {

//     var id = $('#id').val();

//     $.ajax({
//         type: "GET",
//         dataType: "json",
//         url: "/products/"+id,
//         success: function(response) {
//             console.log(response);

//             var data = "";

//             $.each(response, function(key, value){
//                 console.log(value);

//                 data = data + "<div>"

//                     data = data + "<p>"+value.comment+"</p>";
//                     data = data + "<p>"+value.rating+"</p>";

//                 data = data + "</div>"

//             })

//             $('.comment_holder').html(data);
//         },
//         error: function(error) {
//             console.log(error);
//         }
//     })


// }

// allComments();


</script>

<?php $__env->stopSection(); ?>




























<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\om\resources\views/product/show.blade.php ENDPATH**/ ?>