<?php $__env->startSection('title','Home page'); ?>

<?php $__env->startSection('content'); ?>

<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">

    <div class="carousel-inner">


        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sliderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php echo e($key == 0 ? 'active':''); ?>">

        <?php if($sliderItem->image): ?>
        <img src="<?php echo e(asset("$sliderItem->image")); ?>" class="d-block w-100" alt="...">
        <?php endif; ?>

        <div class="carousel-caption d-none d-md-block">
            <h5><?php echo e($sliderItem-> title); ?></h5>
            <p><?php echo e($sliderItem-> description); ?></p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\om\resources\views/frontend/index.blade.php ENDPATH**/ ?>